(function(){
 const page=location.pathname.split("/").pop();
 const role=localStorage.getItem("loginRole");
 const adminPages=["dashboard.html","anggota.html","periode.html","pembayaran.html","pengeluaran.html","laporan.html","pengaturan.html","profil.html"];
 const studentPages=["dashboard_siswa.html","iuran_saya.html","riwayat_pembayaran.html","laporan_siswa.html","profil_siswa.html"];
 if(adminPages.includes(page) && role!=="Admin"){location.replace("index.html");return;}
 if(studentPages.includes(page) && role!=="Siswa"){location.replace("index.html");return;}
 window.IuranKas={
   get(k,d=[]){try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}},
   set(k,v){localStorage.setItem(k,JSON.stringify(v))},
   logout(){
     if(!confirm("Apakah kamu yakin ingin keluar dari akun?")) return;
     ["loginUser","loginName","loginRole"].forEach(k=>localStorage.removeItem(k));
     location.replace("index.html");
   }
 };
 document.addEventListener("DOMContentLoaded",()=>{
   const name=localStorage.getItem("loginName")||"Pengguna";
   document.querySelectorAll(".header-item b,.user-info b").forEach(el=>{
     if(["Admin","Andi","Bendahara","Siswa"].includes(el.textContent.trim())) el.textContent=name;
   });
   document.querySelectorAll(".user-info span").forEach(el=>el.textContent=role||"");
   const header=document.querySelector("header.header");
   if(header && !header.querySelector("[data-iurankas-logout]")){
     const btn=document.createElement("button");
     btn.type="button";
     btn.dataset.iurankasLogout="true";
     btn.textContent="Keluar";
     btn.title="Logout akun";
     btn.setAttribute("aria-label","Logout akun");
     btn.style.cssText="margin-left:14px;padding:9px 15px;border:1px solid #d0d0d0;border-radius:7px;background:#fff;color:#222;font:inherit;font-size:13px;font-weight:600;cursor:pointer;white-space:nowrap";
     btn.addEventListener("click",()=>window.IuranKas.logout());
     header.appendChild(btn);
   }
 });
})();